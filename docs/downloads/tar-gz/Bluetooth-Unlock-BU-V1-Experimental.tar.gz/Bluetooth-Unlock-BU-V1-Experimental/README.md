# Branch Info
This branch is Experimental, things may not work correctly

# Bluetooth-Unlock
Unlock your Linux Computer using a Bluetooth device when nearby

About
-----
Bluetooth unlock is a python script that checks for your device periodically to check if you are there,
and if no connection is found then your computer locks

Installation
------------
Step 1: Download the files

Step 2: Run install.sh (mandatory)

Step 3: Run Bluetooth-Unlock.py using: sudo python3 Bluetooth-Unlock.py
